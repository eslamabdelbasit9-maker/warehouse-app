# منظومة المستودعات — دليل التسليم لقسم IT

تطبيق ويب عربي لإدارة: صرف قطع الغيار، صرف المواد الخام (خلاطة الاسفلت)، الاعتماد على 3 مراحل لكل صنف بالإيميل، الأرصدة بمتوسط التكلفة المرجح، الوارد بالمرفقات، العهد، ولوحة المتابعة — لكل المواقع في نظام واحد.

## التقنيات
- Python 3.11 + FastAPI + SQLAlchemy + Jinja2 (صفحات تُعرض من السيرفر، بدون مكتبات واجهة خارجية)
- قاعدة البيانات: PostgreSQL (موصى به) أو SQL Server أو SQLite للتجربة — تُحدَّد بـ `DATABASE_URL`
- الدخول: بالإيميل وكلمة المرور (يحددها مدير النظام)، أو بحساب Microsoft 365 إذا أُعدّ Entra ID
- الإيميل: Brevo (مجاني) أو Microsoft Graph أو SMTP

## دورة العمل
1. طالب الصرف يُنشئ الطلب (قطع غيار: موقع + وحدة + سبب إجباري + أصناف، ولا يُسمح بكمية أكبر من الرصيد المتاح. مواد خام: خلاطة الاسفلت + أسطر جهة (مشروع/عميل) + مادة + كمية بالطن، والديزل إجمالي اليوم باللتر تشغيل/تسخين).
2. يصل إيميل للمهندس المعتمد لنوع الوحدة فيه الأصناف وزر **«مراجعة واعتماد»** يفتح صفحة الطلب.
3. المعتمد يعلّم على الأصناف التي يوافق عليها؛ غير المعلَّم يُرفض (الملاحظة إجبارية عند الرفض). الأصناف الموافق عليها فقط تنتقل للمرحلة التالية.
4. المراحل: المهندس المعتمد ← مدير الإنتاج ← الاعتماد النهائي.
5. عند الاعتماد النهائي: يُخصم الرصيد وتُثبَّت تكلفة الصنف بمتوسط السعر المرجح وقتها، ويصل إيميل بالنتيجة لطالب الصرف وأمين المستودع.
6. رفض كل الأصناف في أي مرحلة = الطلب مرفوض ويُبلَّغ طالب الصرف.

متوسط السعر المرجح = (قيمة الرصيد الافتتاحي + قيمة الوارد) ÷ (كمية الافتتاحي + كمية الوارد).

## الصلاحيات
| الصلاحية | ماذا يفعل |
|---|---|
| مدير النظام | كل شيء + شاشة الإدارة |
| أمين مستودع | تسجيل الوارد والعهد والأصناف + إنشاء طلبات |
| طالب صرف | إنشاء طلبات ومتابعتها |
| مهندس معتمد / مدير الإنتاج / الاعتماد النهائي | يعتمد حسب «مسار الاعتماد» |

كل مستخدم يُربط بموقع أو أكثر (أو كل المواقع). المرحلة 1 تُحدَّد حسب نوع الوحدة (كسارة / خلاطة اسفلت / خرسانة ...)، والمرحلتان 2 و3 عامة، ويمكن تخصيص أي مرحلة لموقع معيّن.

## التشغيل المجاني بدون سيرفر (Render + Neon + Brevo)

1. **GitHub**: أنشئ حساب على github.com ← New repository باسم `warehouse-app` (Public) ← «uploading an existing file» واسحب كل محتويات مجلد المشروع ← Commit.
2. **Neon (قاعدة البيانات)**: neon.tech ← Sign up ← Create project (Region: Frankfurt) ← انسخ **Connection string**.
3. **Brevo (الإيميلات)**: brevo.com ← Sign up ← Senders & IP ← Senders ← أضف الإيميل الذي سترسل منه وأكّده ← SMTP & API ← API Keys ← Generate ← انسخ المفتاح.
4. **Render (تشغيل البرنامج)**: render.com ← Sign up with GitHub ← New ← Web Service ← اختر `warehouse-app`:
   - Runtime: Python 3 — Instance type: **Free**
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT --proxy-headers --forwarded-allow-ips "*"`
   - Environment Variables:

| المتغير | القيمة |
|---|---|
| `PYTHON_VERSION` | `3.11.9` |
| `DATABASE_URL` | رابط Neon |
| `SECRET_KEY` | أي نص عشوائي طويل |
| `BASE_URL` | `https://<اسم-الخدمة>.onrender.com` |
| `BOOTSTRAP_ADMIN_EMAIL` | إيميلك |
| `BOOTSTRAP_ADMIN_NAME` | اسمك |
| `BOOTSTRAP_ADMIN_PASSWORD` | كلمة مرور أول دخول |
| `MAIL_MODE` | `brevo` |
| `MAIL_SENDER` | الإيميل الذي أكّدته في Brevo |
| `BREVO_API_KEY` | مفتاح Brevo |

5. Deploy ← افتح الرابط ← ادخل بإيميلك وكلمة المرور ← الإدارة ← **استيراد من Excel** وارفع ملف نجران.
6. (اختياري) الخدمة المجانية تنام بعد 15 دقيقة بدون استخدام وأول فتح بعدها يأخذ قرابة دقيقة. لإبقائها صاحية: cron-job.org ← Create cronjob ← الرابط `https://<اسم-الخدمة>.onrender.com/login` كل 10 دقائق.

أي تعديل لاحق على الكود: ارفعه على GitHub وRender يحدّث تلقائياً. البيانات محفوظة في Neon ولا تتأثر.

---

## خطوات التشغيل على سيرفر الشركة (بديل)

### 1) تسجيل التطبيق في Entra ID (مرة واحدة)
في portal.azure.com ← **Microsoft Entra ID ← App registrations ← New registration**:
- Name: `Warehouse System`
- Supported account types: **Single tenant**
- Redirect URI (Web): `https://<عنوان-النظام>/auth/callback`

بعدها:
- **Certificates & secrets ← New client secret** — احفظ القيمة.
- **API permissions ← Add ← Microsoft Graph**:
  - Delegated: `User.Read` (للدخول)
  - Application: `Mail.Send` ← ثم **Grant admin consent**
- (موصى به) قصر الإرسال على الصندوق المشترك فقط عبر Exchange Online PowerShell:
  ```powershell
  New-ApplicationAccessPolicy -AppId <CLIENT_ID> -PolicyScopeGroupId warehouse@company.com -AccessRight RestrictAccess -Description "Warehouse app send only"
  ```
- أنشئ صندوق بريد مشترك مثل `warehouse@company.com` يُرسَل منه.

انسخ `Directory (tenant) ID` و`Application (client) ID` والـ Secret إلى ملف `.env`.

### 2) الإعدادات
```bash
cp .env.example .env    # ثم عدّل القيم
```
أهمها: `BASE_URL` (العنوان الذي يفتحه المستخدمون — يُستخدم في روابط الإيميل)، `SECRET_KEY`، `DEV_AUTH=false`، بيانات Entra، `MAIL_MODE=graph`، `MAIL_SENDER`، و`BOOTSTRAP_ADMIN_EMAIL`.

### 3) التشغيل بـ Docker (مع PostgreSQL)
```bash
DB_PASSWORD=<كلمة-سر-قوية> docker compose up -d --build
```
ضع النظام خلف HTTPS (IIS/Nginx/Azure App Service). الجداول تُنشأ تلقائياً عند أول تشغيل.

بدون Docker:
```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --proxy-headers
```

### 4) نقل بيانات نجران من ملف Excel الحالي
```bash
docker compose exec app python -m scripts.import_excel --file "/app/data/منظومة_المستودعات_نجران.xlsx" --site-code NJR --site-name "نجران"
```
يستورد: الأصناف (336) والرصيد الافتتاحي، الوارد مجمّعاً بالفاتورة، وكل طلبات الصرف المعتمدة والمرفوضة. تمت مطابقته على الملف الحالي: رصيد كل الأصناف ومتوسط السعر وقيمة الرصيد (730,845.02) وقيمة المنصرف (417,327.02) مطابقة 100%.
لكل موقع جديد يُشغَّل نفس الأمر بملفه وكود مختلف، أو يُدخل الموقع والأرصدة الافتتاحية من شاشة الإدارة.

### 5) الإعداد من داخل النظام (بحساب مدير النظام)
1. **الإدارة ← المواقع والوحدات**: أضف المواقع (الضيقة/نجران، مكة، الدار، الكدمي، الجنادرية، تبوك...) ووحدات كل موقع ونوعها.
2. **المستخدمون والصلاحيات**: أضف كل مستخدم بإيميل Microsoft 365 وحدد صلاحياته ومواقعه.
3. **مسار الاعتماد**: المرحلة 1 لكل نوع وحدة (مهندس الكسارة، مهندس الاسفلت...)، المرحلة 2 مدير الإنتاج، المرحلة 3 الاعتماد النهائي.
4. جرّب طلباً وتابع **سجل الإيميلات** للتأكد من الإرسال.

---

## التجربة على جهاز محلي
```bash
pip install -r requirements.txt
python -m scripts.import_excel --file "منظومة_المستودعات_نجران.xlsx" --site-code NJR --site-name "نجران"   # اختياري
python -m scripts.seed_demo        # مستخدمون تجريبيون ومسار اعتماد
uvicorn app.main:app --reload
```
افتح http://localhost:8000 — في وضع التجربة (`DEV_AUTH=true` في ملف `.env`) تظهر قائمة لاختيار المستخدم، والإيميلات لا تُرسل بل تُحفظ في **الإدارة ← سجل الإيميلات** (`MAIL_MODE=outbox`).

الاختبارات:
```bash
python -m pytest -q
```

## النسخ الاحتياطي
- قاعدة البيانات (pg_dump يومي).
- مجلد المرفقات `data/uploads` (أو الـ volume `uploads`).

## ملاحظات أمان
- `DEV_AUTH` يجب أن يكون `false` في التشغيل الفعلي.
- لا يدخل إلا من سجّله مدير النظام؛ أي حساب آخر من الشركة يظهر له «غير مسموح».
- صفحة الاعتماد تتطلب تسجيل الدخول، ولا يستطيع الاعتماد إلا المعتمد المحدد للمرحلة الحالية، ولا يُعتمد الطلب مرتين.
- المرفقات: PDF/صور/Excel/Word حتى 10 ميجا، ولا تُفتح إلا لمستخدم مسجّل.

## هيكل المشروع
```
app/
  main.py        الصفحات والمسارات
  services.py    الأرصدة، الترقيم، مسار الاعتماد، الإيميلات
  models.py      جداول قاعدة البيانات
  auth.py        الدخول بـ Microsoft 365
  mailer.py      الإرسال (Graph / SMTP / سجل داخلي)
  templates/     الواجهات (عربي RTL)
scripts/
  import_excel.py  استيراد بيانات موقع من Excel
  seed_demo.py     بيانات تجريبية
tests/test_flow.py اختبار الدورة كاملة
```
